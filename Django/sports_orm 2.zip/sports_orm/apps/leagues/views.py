from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Count
from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.filter(sport__contains="baseball"),
		"wleagues" : League.objects.filter(name__contains="women"),
		"hockies" : League.objects.filter(sport__contains="hockey"),
		"footballs" : League.objects.exclude(sport__contains="football"),
		"conferences" : League.objects.filter(name__contains="conference"),
		"atlleagues" : League.objects.filter(name__contains="atlantic"),
		"dteams" : Team.objects.filter(location='Dallas'),
		"raptors" : Team.objects.filter(team_name__contains='raptor'),
		"cteams" : Team.objects.filter(location__contains="city"),
		"tteams" : Team.objects.filter(team_name__startswith="T"),
		"allteams": Team.objects.order_by('location'),
		"allteamsr": Team.objects.order_by('-location'),
		"coopers" : Player.objects.filter(last_name = 'Cooper'),
		"joshuas" : Player.objects.filter(first_name = 'Joshua'),
		"cooperjs" : Player.objects.filter(last_name = 'Cooper').exclude(first_name = 'Joshua'),
		'alexas' : Player.objects.filter(first_name = 'Alexander').order_by('first_name')| Player.objects.filter(first_name='Wyatt').order_by('first_name'),
		# "teams": Team.objects.all(),
		# "players": Player.objects.all(),
		# ############### #
		# PART TWOOOO!!!! #
		# ############### #
		'atlsoccer' : Team.objects.filter(league=League.objects.get(id=5)),
		'penguins' : Player.objects.filter(curr_team__team_name__contains = "penguins"),
		'icbcs' : Player.objects.filter(curr_team__league__name__contains='collegiate'),
		'footlopezs' : Player.objects.filter(curr_team__league__name__contains='American Conference of Amateur Football').filter(last_name__contains='lopez'),
		'footplayers' : Player.objects.filter(curr_team__league__sport__contains="football"),
		'sophias' : Player.objects.filter(first_name__contains='sophia'),
		'flores' : Player.objects.filter(last_name__contains='flores').exclude(curr_team__team_name__contains='rough'),
		'evans' : Team.objects.all().filter(all_players='115'),
		'tigercats' : Player.objects.all().filter(all_teams='37'),
		'vikings' : Player.objects.all().filter(all_teams='40').exclude(curr_team_id='40'),
		'jacobs' : Team.objects.all().filter(all_players='151').exclude(team_name__contains = 'colt'),
		'joshuas' : Player.objects.all().filter(first_name__contains='joshua').filter(all_teams='3'),
		'allteams' : Team.objects.annotate(sum_players =Count('all_players')).filter(sum_players__gte=12),
		'playerteams' : Player.objects.annotate(sum_teams = Count('all_teams')).order_by("-sum_teams")
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	# team_maker.gen_teams(50)
	team_maker.gen_teams(100)
	team_maker.gen_players(200)

	return redirect("index")
