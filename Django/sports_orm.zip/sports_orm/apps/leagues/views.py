from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.filter(sport__contains="baseball"),
		"wleagues" : League.objects.filter(name__contains="women"),
		"hockies" : League.objects.filter(sport__contains="hockey"),
		"footballs" : League.objects.exclude(sport__contains="football"),
		"conferences" : League.objects.filter(name__contains="conference"),
		"atlleagues" : League.objects.filter(name__contains="atlantic"),
		"dteams" : Team.objects.filter(location='Dallas'),
		"raptors" : Team.objects.filter(team_name__contains='raptor'),
		"cteams" : Team.objects.filter(location__contains="city"),
		"tteams" : Team.objects.filter(team_name__startswith="T"),
		"allteams": Team.objects.order_by('location'),
		"allteamsr": Team.objects.order_by('-location'),
		"coopers" : Player.objects.filter(last_name = 'Cooper'),
		"joshuas" : Player.objects.filter(first_name = 'Joshua'),
		"cooperjs" : Player.objects.filter(last_name = 'Cooper').exclude(first_name = 'Joshua'),
		'alexas' : Player.objects.filter(first_name = 'Alexander').order_by('first_name')| Player.objects.filter(first_name='Wyatt').order_by('first_name'),
		# "teams": Team.objects.all(),
		# "players": Player.objects.all(),
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
