var app = angular.module('app',[]);

app.factory('productFactory',function(){
  var products = [];
  var factory = {}
  factory.getProducts = function(){
    // callback(products);
    return products;
  }
  factory.addProduct = function(product){
    products.push(product);
  }
  factory.removeProduct = function(product){
    products.splice(product,1);
  }
  return factory;
})
app.controller('productController',['$scope','productFactory',function($scope, productFactory){
  $scope.products = productFactory.getProducts();
  $scope.removeProduct = function(product){
    productFactory.removeProduct(product);
  }
  $scope.addProduct = function(){
    productFactory.addProduct($scope.newProd);
    $scope.newProd = {};
    console.log($scope.products);
  }
  // productFactory.getProducts(function(data){
  //   $scope.products = data;
  // })
}]);
