var mathlibs = require('./mathlibs')();
console.log(mathlibs);
console.log(mathlibs.add(1,2));
console.log(mathlibs.multiply(3,2));
console.log(mathlibs.square(10));
console.log(mathlibs.random(1,35));
